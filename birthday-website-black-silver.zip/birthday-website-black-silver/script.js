// EDIT bagian konfigurasi ini sesuai kebutuhanmu.
const CONFIG = {
  personName: "Someone Special",
  senderName: "someone who cares",
  // Format: TAHUN-BULAN-TANGGALTJJ:MM:SS
  // Contoh: "2026-12-25T00:00:00"
  birthday: "2026-12-25T00:00:00",
  letter: `Selamat ulang tahun! Semoga hari-harimu dipenuhi hal-hal baik,
tawa yang tulus, orang-orang yang menyayangimu, dan mimpi yang
perlahan menjadi nyata. Terima kasih sudah menjadi dirimu sendiri.
Semoga tahun baru dalam hidupmu membawa banyak cerita indah.`
};

document.title = `For ${CONFIG.personName} ♡`;
document.getElementById("person-name").textContent = CONFIG.personName;
document.getElementById("sender-name").textContent = CONFIG.senderName;
document.getElementById("letter-text").textContent = CONFIG.letter;

const targetDate = new Date(CONFIG.birthday);
const pad = n => String(n).padStart(2, "0");
function updateCountdown() {
  const now = new Date();
  let diff = targetDate.getTime() - now.getTime();
  const note = document.getElementById("countdown-note");
  if (Number.isNaN(targetDate.getTime())) {
    note.textContent = "Periksa format tanggal ulang tahun di script.js.";
    return;
  }
  if (diff <= 0) {
    ["days", "hours", "minutes", "seconds"].forEach(id => document.getElementById(id).textContent = "00");
    note.textContent = "Hari spesialnya sudah tiba! Selamat ulang tahun ♡";
    return;
  }
  const days = Math.floor(diff / 86400000); diff %= 86400000;
  const hours = Math.floor(diff / 3600000); diff %= 3600000;
  const minutes = Math.floor(diff / 60000); diff %= 60000;
  const seconds = Math.floor(diff / 1000);
  document.getElementById("days").textContent = pad(days);
  document.getElementById("hours").textContent = pad(hours);
  document.getElementById("minutes").textContent = pad(minutes);
  document.getElementById("seconds").textContent = pad(seconds);
}
updateCountdown();
setInterval(updateCountdown, 1000);

const toast = document.getElementById("toast");
let toastTimer;
function showToast(message) {
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 2600);
}
function hearts(amount = 14) {
  const symbols = ["♡", "♥", "✧", "✦"];
  for (let i = 0; i < amount; i++) {
    const heart = document.createElement("span");
    heart.className = "heart";
    heart.textContent = symbols[Math.floor(Math.random() * symbols.length)];
    heart.style.left = `${8 + Math.random() * 84}%`;
    heart.style.bottom = `${10 + Math.random() * 20}px`;
    heart.style.fontSize = `${14 + Math.random() * 20}px`;
    heart.style.color = ["#ffb8d5", "#fff0f8", "#f37eb6"][i % 3];
    document.body.appendChild(heart);
    setTimeout(() => heart.remove(), 1900);
  }
}
function revealAndScroll(id) {
  const section = document.getElementById(id);
  section.classList.add("visible");
  section.scrollIntoView({ behavior: "smooth", block: "start" });
}

document.getElementById("open-surprise").addEventListener("click", () => {
  revealAndScroll("letter");
  hearts(22);
  showToast(`Kejutan kecil untuk ${CONFIG.personName} ♡`);
});
document.getElementById("show-gallery").addEventListener("click", () => {
  revealAndScroll("gallery");
  hearts(10);
});
document.getElementById("final-button").addEventListener("click", () => {
  revealAndScroll("final");
  hearts(24);
});
document.getElementById("back-top").addEventListener("click", () => {
  window.scrollTo({ top: 0, behavior: "smooth" });
  showToast("Semoga harimu indah ✨");
});

const audio = document.getElementById("bg-music");
const musicButton = document.getElementById("music-toggle");
musicButton.addEventListener("click", async () => {
  if (audio.paused) {
    try {
      await audio.play();
      musicButton.textContent = "♫ Matikan musik";
      musicButton.setAttribute("aria-pressed", "true");
    } catch {
      showToast("Tambahkan file music/song.mp3 terlebih dahulu ya.");
    }
  } else {
    audio.pause();
    musicButton.textContent = "♫ Putar musik";
    musicButton.setAttribute("aria-pressed", "false");
  }
});

const observer = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add("visible");
      observer.unobserve(entry.target);
    }
  });
}, { threshold: 0.12 });
document.querySelectorAll(".reveal").forEach(section => observer.observe(section));
