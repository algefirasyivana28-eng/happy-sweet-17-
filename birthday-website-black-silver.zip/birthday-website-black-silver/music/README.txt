Taruh musik yang boleh kamu gunakan di folder ini dan beri nama song.mp3.
Browser biasanya hanya memutar musik setelah pengunjung menekan tombol Putar musik.
