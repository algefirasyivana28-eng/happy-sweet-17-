Taruh foto kamu di folder ini dengan nama foto1.jpg, foto2.jpg, dan foto3.jpg.
Kamu boleh menggunakan JPG atau mengubah nama file di index.html.
