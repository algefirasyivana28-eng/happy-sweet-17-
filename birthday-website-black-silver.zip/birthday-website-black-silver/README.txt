WEBSITE ULANG TAHUN — BLACK & SILVER

Isi folder:
- index.html  : struktur dan teks website
- style.css   : tampilan hitam, putih, dan silver
- script.js   : countdown, tombol, animasi, dan musik
- images/     : tempat foto-foto
- music/      : tempat file musik

CARA MENGEDIT:
1. Buka index.html untuk mengganti nama, surat, dan tulisan.
2. Masukkan foto kamu ke folder images dengan nama foto1.jpg, foto2.jpg, foto3.jpg.
3. Masukkan musik milikmu ke folder music dengan nama song.mp3.
4. Buka file index.html di browser untuk melihat hasilnya.

CARA UPLOAD KE GITHUB PAGES:
1. Buat repository baru di GitHub.
2. Upload semua ISI folder ini (bukan ZIP-nya saja) ke repository.
3. Masuk Settings > Pages.
4. Di bagian Build and deployment, pilih Deploy from a branch.
5. Pilih branch main dan folder /(root), lalu Save.
6. Tunggu sampai link website muncul.

Catatan:
- Ubah tanggal countdown di script.js supaya sesuai tanggal ulang tahun.
- Website ini dibuat responsif untuk layar HP dan laptop.
- Ini versi template yang terinspirasi dari urutan video: countdown, surat ulang tahun, galeri kenangan, dan halaman penutup. Tidak bisa menjamin identik piksel demi piksel.
